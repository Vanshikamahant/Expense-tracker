
// taken from stack overflow or other resources to show currency model
export const currFormatter = new Intl.NumberFormat(undefined,{
    currency :"inr",
    style : "currency",
    minimumFractionDigits:0,
})
